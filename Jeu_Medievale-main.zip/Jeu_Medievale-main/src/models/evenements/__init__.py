from .evenement import Evenement
from .evenement_recolte_abondante import RecolteAbondante
from .evenement_epidemie import Epidemie

