from .personne import Personne
from .roturier import Roturier
from .paysan import Paysan
from .noble import Noble
from .seigneur import Seigneur
from .soldat import Soldat
