from enum import Enum

class TYPE(Enum):
    plaine = "plaine"
    eau = "eau"
    foret = "foret"
    montagne = "montagne"
    village = "village"
    foretclair = "foretclair"
    eauclair= "eauclair"
    montagneclair = "montagneclair"