from .menu import MenuPrincipal
from .interface import JeuInterface
from .map import Map
from .Case import Case
from src.views import TYPE